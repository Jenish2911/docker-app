export const theme = {
    primary: '#0db7ed',
    secondary: '#384d54',
    background: '#f4f5f7',
    text: '#333',
    white: '#ffffff',
  };